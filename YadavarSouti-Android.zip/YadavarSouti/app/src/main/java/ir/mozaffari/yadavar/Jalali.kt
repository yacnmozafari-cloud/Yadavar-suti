package ir.mozaffari.yadavar

import java.util.Calendar

/** تبدیل تاریخ شمسی و میلادی (الگوریتم jalaali) */
object Jalali {
    data class JDate(val jy: Int, val jm: Int, val jd: Int)

    val MONTHS = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
    // Calendar.DAY_OF_WEEK: 1 = یکشنبه ... 7 = شنبه
    private val WEEK = listOf("یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه")

    private val breaks = intArrayOf(-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178)
    private fun div(a: Int, b: Int) = a / b
    private fun mod(a: Int, b: Int) = a - (a / b) * b

    private data class Cal(val leap: Int, val gy: Int, val march: Int)

    private fun jalCal(jy: Int): Cal {
        val gy = jy + 621
        var leapJ = -14
        var jp = breaks[0]
        var jump = 0
        for (i in 1 until breaks.size) {
            val jm = breaks[i]
            jump = jm - jp
            if (jy < jm) break
            leapJ += div(jump, 33) * 8 + div(mod(jump, 33), 4)
            jp = jm
        }
        var n = jy - jp
        leapJ += div(n, 33) * 8 + div(mod(n, 33) + 3, 4)
        if (mod(jump, 33) == 4 && jump - n == 4) leapJ += 1
        val leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150
        val march = 20 + leapJ - leapG
        if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33
        var leap = mod(mod(n + 1, 33) - 1, 4)
        if (leap == -1) leap = 4
        return Cal(leap, gy, march)
    }

    private fun g2d(gy: Int, gm: Int, gd: Int): Int {
        val d = div((gy + div(gm - 8, 6) + 100100) * 1461, 4) + div(153 * mod(gm + 9, 12) + 2, 5) + gd - 34840408
        return d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752
    }

    private fun d2g(jdn: Int): IntArray {
        var j = 4 * jdn + 139361631
        j += div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908
        val i = div(mod(j, 1461), 4) * 5 + 308
        val gd = div(mod(i, 153), 5) + 1
        val gm = mod(div(i, 153), 12) + 1
        val gy = div(j, 1461) - 100100 + div(8 - gm, 6)
        return intArrayOf(gy, gm, gd)
    }

    private fun j2d(jy: Int, jm: Int, jd: Int): Int {
        val r = jalCal(jy)
        return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1
    }

    private fun d2j(jdn: Int): JDate {
        val gy = d2g(jdn)[0]
        var jy = gy - 621
        val r = jalCal(jy)
        val jdn1f = g2d(gy, 3, r.march)
        var k = jdn - jdn1f
        if (k >= 0) {
            if (k <= 185) return JDate(jy, 1 + div(k, 31), mod(k, 31) + 1)
            k -= 186
        } else {
            jy -= 1
            k += 179
            if (r.leap == 1) k += 1
        }
        return JDate(jy, 7 + div(k, 30), mod(k, 30) + 1)
    }

    fun fromMillis(ms: Long): JDate {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        return d2j(g2d(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)))
    }

    fun toMillis(jy: Int, jm: Int, jd: Int, hour: Int, minute: Int): Long {
        val g = d2g(j2d(jy, jm, jd))
        return Calendar.getInstance().apply {
            set(g[0], g[1] - 1, g[2], hour, minute, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    fun isLeap(jy: Int) = jalCal(jy).leap == 0
    fun monthLength(jy: Int, jm: Int) = when {
        jm <= 6 -> 31
        jm <= 11 -> 30
        isLeap(jy) -> 30
        else -> 29
    }

    fun fa(s: Any): String = s.toString().map { if (it in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[it - '0'] else it }.joinToString("")
    fun en(s: String): String = s.map {
        when (it) {
            in '۰'..'۹' -> '0' + (it - '۰')
            in '٠'..'٩' -> '0' + (it - '٠')
            else -> it
        }
    }.joinToString("")

    private fun two(n: Int) = n.toString().padStart(2, '0')

    fun format(ms: Long, withWeek: Boolean = true): String {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        val j = fromMillis(ms)
        val week = if (withWeek) WEEK[c.get(Calendar.DAY_OF_WEEK) - 1] + " " else ""
        return fa("$week${j.jd} ${MONTHS[j.jm - 1]} ${j.jy} — ساعت ${two(c.get(Calendar.HOUR_OF_DAY))}:${two(c.get(Calendar.MINUTE))}")
    }

    fun today(ms: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        val j = fromMillis(ms)
        return fa("${WEEK[c.get(Calendar.DAY_OF_WEEK) - 1]} ${j.jd} ${MONTHS[j.jm - 1]} ${j.jy}")
    }

    fun clock(ms: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        return fa("${two(c.get(Calendar.HOUR_OF_DAY))}:${two(c.get(Calendar.MINUTE))}")
    }

    fun left(ms: Long): String {
        if (ms <= 0) return "همین حالا"
        val m = ms / 60000
        val d = m / 1440
        val h = (m % 1440) / 60
        val mi = m % 60
        val parts = mutableListOf<String>()
        if (d > 0) parts += "$d روز"
        if (h > 0) parts += "$h ساعت"
        if (d == 0L && mi > 0) parts += "$mi دقیقه"
        if (parts.isEmpty()) parts += "${(ms + 999) / 1000} ثانیه"
        return fa(parts.joinToString(" و ") + " دیگر")
    }
}
