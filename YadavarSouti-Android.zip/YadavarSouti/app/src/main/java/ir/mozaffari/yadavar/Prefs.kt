package ir.mozaffari.yadavar

import android.content.Context

object Prefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun voice(ctx: Context) = sp(ctx).getBoolean("voice", true)
    fun setVoice(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("voice", v).apply()
}
