package ir.mozaffari.yadavar

/** خواندن دستور فارسی مثل «۱۵ آبان ساعت ۸:۳۰ صبح جلسه با مدیر» */
object CommandParser {
    data class Result(
        val date: Jalali.JDate?,
        val hour: Int?,
        val minute: Int?,
        val text: String,
    )

    private const val PARTS = "(صبح|ظهر|بعد از ظهر|بعدازظهر|عصر|شب)"

    fun parse(raw: String, now: Long = System.currentTimeMillis()): Result {
        var s = " " + Jalali.en(raw).replace('ي', 'ی').replace('ك', 'ک').replace('\u200c', ' ')
            .replace(Regex("\\s+"), " ") + " "
        val nowJ = Jalali.fromMillis(now)
        var date: Jalali.JDate? = null
        var hour: Int? = null
        var minute: Int? = null
        var night = false

        fun cut(m: MatchResult) { s = s.replaceFirst(m.value, " ") }

        // نسبی: «۱۰ دقیقه دیگه»، «۲ روز بعد»
        Regex("(\\d+)\\s*(دقیقه|ساعت|روز|هفته)\\s*(دیگه|دیگر|بعد)").find(s)?.let { m ->
            val n = m.groupValues[1].toLong()
            val ms = when (m.groupValues[2]) {
                "دقیقه" -> n * 60_000L
                "ساعت" -> n * 3_600_000L
                "روز" -> n * 86_400_000L
                else -> n * 604_800_000L
            }
            val t = now + ms
            date = Jalali.fromMillis(t)
            if (m.groupValues[2] == "دقیقه" || m.groupValues[2] == "ساعت") {
                val c = java.util.Calendar.getInstance().apply { timeInMillis = t }
                hour = c.get(java.util.Calendar.HOUR_OF_DAY); minute = c.get(java.util.Calendar.MINUTE)
            }
            cut(m)
        }

        // عددی: 1405/08/15
        if (date == null) Regex("(\\d{4})\\s*[/\\-.]\\s*(\\d{1,2})\\s*[/\\-.]\\s*(\\d{1,2})").find(s)?.let { m ->
            date = Jalali.JDate(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt()); cut(m)
        }

        // «۱۵ آبان» یا «۱۵ آبان ۱۴۰۶»
        if (date == null) {
            val names = Jalali.MONTHS.joinToString("|")
            Regex("(\\d{1,2})\\s*(?:ام|م)?\\s*($names)(?:\\s*(?:ماه)?\\s*(?:سال)?\\s*(\\d{4}))?").find(s)?.let { m ->
                val mi = Jalali.MONTHS.indexOf(m.groupValues[2]) + 1
                val d = m.groupValues[1].toInt()
                var jy = m.groupValues[3].toIntOrNull() ?: nowJ.jy
                if (m.groupValues[3].isEmpty() && (mi < nowJ.jm || (mi == nowJ.jm && d < nowJ.jd))) jy += 1
                date = Jalali.JDate(jy, mi, d); cut(m)
            }
        }

        // امروز / فردا / پس‌فردا / امشب
        if (date == null) {
            for ((w, n) in listOf("پس فردا" to 2, "پسفردا" to 2, "فردا" to 1, "امروز" to 0, "امشب" to 0)) {
                if (s.contains(w)) {
                    date = Jalali.fromMillis(now + n * 86_400_000L)
                    if (w == "امشب") night = true
                    s = s.replaceFirst(w, " ")
                    break
                }
            }
        }

        // ساعت
        if (hour == null) {
            val m = Regex("ساعت\\s*(\\d{1,2})(?:\\s*[:٫.]\\s*(\\d{1,2}))?(\\s*و\\s*(نیم|ربع|سی|پانزده|چهل و پنج))?(?:\\s*دقیقه)?(\\s*$PARTS)?").find(s)
                ?: Regex("(\\d{1,2})\\s*:\\s*(\\d{2})()()(\\s*$PARTS)?").find(s)
            if (m != null) {
                var h = m.groupValues[1].toInt()
                var mi = m.groupValues[2].toIntOrNull() ?: 0
                when (m.groupValues[4]) {
                    "نیم", "سی" -> mi = 30
                    "ربع", "پانزده" -> mi = 15
                    "چهل و پنج" -> mi = 45
                }
                val p = m.groupValues[6].ifEmpty { if (night) "شب" else "" }
                if (Regex("بعد از ظهر|بعدازظهر|عصر|شب").containsMatchIn(p) && h < 12) h += 12
                if (p == "ظهر" && h < 6) h += 12
                if (h == 24) h = 0
                hour = h.coerceIn(0, 23); minute = mi.coerceIn(0, 59)
                cut(m)
            }
        }

        s = s.replace(Regex("(یادم|یاد م)\\s*(بنداز|بیار|بده)|یادآوری\\s*(کن|بکن)"), " ")
            .replace(Regex("(?<=\\s)(بهم|به من|لطفا|لطفاً|برام|که|در تاریخ|تاریخ|روز)(?=\\s)"), " ")
        val text = s.replace(Regex("\\s+"), " ").trim().trim('،', ',', '.', ':', '-', ' ')
        return Result(date, hour, minute, text)
    }
}
