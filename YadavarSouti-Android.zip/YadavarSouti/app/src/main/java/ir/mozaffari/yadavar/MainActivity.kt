package ir.mozaffari.yadavar

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.util.Calendar

class MainActivity : ComponentActivity() {
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { AppRoot(resumeTick.intValue) } }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
    }
}

private const val DESIGNER = "یاسین مظفری"

@Composable
fun AppRoot(resumeTick: Int) {
    val ctx = LocalContext.current
    var splash by remember { mutableStateOf(true) }
    var tab by remember { mutableIntStateOf(0) }
    val items = remember { mutableStateListOf<Reminder>() }

    fun reload() { items.clear(); items.addAll(ReminderStore.pending(ctx)) }
    LaunchedEffect(resumeTick) { reload() }
    LaunchedEffect(Unit) { delay(1700); splash = false }

    if (splash) { Splash(); return }

    Scaffold(
        containerColor = Paper,
        topBar = { AppBar() },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                val navColors = NavigationBarItemDefaults.colors(selectedIconColor = Saffron, selectedTextColor = Ink, indicatorColor = SaffronSoft)
                listOf(
                    Triple(R.drawable.ic_alarm, "یادآور جدید", 0),
                    Triple(R.drawable.ic_list, if (items.isEmpty()) "فهرست" else "فهرست (${Jalali.fa(items.size)})", 1),
                    Triple(R.drawable.ic_sound, "تنظیمات", 2),
                    Triple(R.drawable.ic_info, "درباره", 3),
                ).forEach { (icon, label, i) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i }, colors = navColors,
                        icon = { Icon(painterResource(icon), null) },
                        label = { Text(label, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen { reload(); tab = 1 }
                1 -> ListScreen(items) { reload() }
                2 -> SettingsScreen(resumeTick)
                else -> AboutScreen()
            }
        }
    }
}

@Composable
fun AppIcon(size: Int) {
    Box(
        Modifier.size(size.dp).background(Ink, RoundedCornerShape((size / 4).dp)),
        contentAlignment = Alignment.Center
    ) { Icon(painterResource(R.drawable.ic_stat_alarm), null, tint = Saffron, modifier = Modifier.size((size * 0.6).dp)) }
}

@Composable
fun Splash() {
    Box(Modifier.fillMaxSize().background(Ink), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            AppIcon(104)
            Spacer(Modifier.height(18.dp))
            Text("یادآور صوتی شمسی", color = Paper, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text("طراحی و توسعه: $DESIGNER", color = Saffron, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
fun AppBar() {
    Row(
        Modifier.fillMaxWidth().background(Paper).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(38)
        Spacer(Modifier.width(10.dp))
        Column {
            Text("یادآور صوتی شمسی", fontWeight = FontWeight.Black, fontSize = 17.sp)
            Text("طراحی: $DESIGNER", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun Card(content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 8.dp)
            .background(Color.White, RoundedCornerShape(14.dp))
            .border(1.dp, Line, RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) { content() }
}

@Composable
fun Picker(label: String, options: List<Pair<Int, String>>, selected: Int, modifier: Modifier = Modifier, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column(modifier) {
        Text(label, color = Muted, fontSize = 13.sp)
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(8.dp)) {
                Text(options.firstOrNull { it.first == selected }?.second ?: "-", color = Ink)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { (v, t) -> DropdownMenuItem(text = { Text(t) }, onClick = { onSelect(v); open = false }) }
            }
        }
    }
}

@Composable
fun HomeScreen(onAdded: () -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }

    val start = remember { Jalali.fromMillis(System.currentTimeMillis()) }
    val startCal = remember { Calendar.getInstance().apply { add(Calendar.MINUTE, 10) } }
    var jy by remember { mutableIntStateOf(start.jy) }
    var jm by remember { mutableIntStateOf(start.jm) }
    var jd by remember { mutableIntStateOf(start.jd) }
    var hour by remember { mutableIntStateOf(startCal.get(Calendar.HOUR_OF_DAY)) }
    var minute by remember { mutableIntStateOf(startCal.get(Calendar.MINUTE)) }
    var text by remember { mutableStateOf("") }
    var cmd by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("") }

    fun applyCommand() {
        val r = CommandParser.parse(cmd)
        r.date?.let { jy = it.jy; jm = it.jm; jd = it.jd.coerceIn(1, Jalali.monthLength(it.jy, it.jm)) }
        if (r.hour != null) { hour = r.hour; minute = r.minute ?: 0 }
        if (r.text.isNotEmpty()) text = r.text
        val miss = buildList { if (r.date == null) add("تاریخ"); if (r.hour == null) add("ساعت"); if (r.text.isEmpty()) add("متن") }
        info = if (miss.isEmpty()) "دستور خوانده شد. بررسی کنید و «ثبت یادآور» را بزنید."
        else "${miss.joinToString(" و ")} در دستور پیدا نشد؛ آن را در فرم پایین کامل کنید."
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val list = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        if (!list.isNullOrEmpty()) { cmd = list[0]; applyCommand() }
    }
    fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "دستور یادآور را بگویید")
        try { speech.launch(i) } catch (_: ActivityNotFoundException) {
            info = "تشخیص گفتار روی این گوشی نصب نیست؛ برنامه Google را نصب کنید یا دستور را تایپ کنید."
        }
    }

    val at = Jalali.toMillis(jy, jm, jd.coerceAtMost(Jalali.monthLength(jy, jm)), hour, minute)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        // ساعت زنده
        Column(Modifier.padding(vertical = 10.dp)) {
            Text("ساعت و تاریخ امروز", color = Muted, fontSize = 14.sp)
            Text(Jalali.clock(now), fontSize = 72.sp, fontWeight = FontWeight.Black, lineHeight = 80.sp)
            Text(Jalali.today(now), fontSize = 19.sp, fontWeight = FontWeight.Bold)
            HorizontalDivider(Modifier.padding(top = 14.dp), thickness = 2.dp, color = Ink)
        }

        Card {
            Text("دستور بدهید", fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text("بنویسید یا با میکروفون بگویید چه چیزی، چه روزی و چه ساعتی یادتان بیاید.", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = cmd, onValueChange = { cmd = it }, modifier = Modifier.weight(1f),
                    placeholder = { Text("مثلاً: ۱۵ آبان ساعت ۸:۳۰ صبح جلسه با مدیر") }
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.size(56.dp).background(Saffron, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    TextButton(onClick = { listen() }, modifier = Modifier.fillMaxSize(), shape = CircleShape) {
                        Icon(painterResource(R.drawable.ic_mic), "گفتن دستور", tint = Ink)
                    }
                }
            }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("۱۰ دقیقه دیگه ", "فردا ساعت ۸ صبح ", "امشب ساعت ۱۰ ").forEach { c ->
                    OutlinedButton(onClick = { cmd = c; applyCommand() }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)) {
                        Text(c.trim(), fontSize = 12.sp, color = Muted)
                    }
                }
            }
            OutlinedButton(onClick = { applyCommand() }, modifier = Modifier.padding(top = 6.dp)) { Text("خواندن دستور", color = Ink) }
            if (info.isNotEmpty()) Text(info, color = OkGreen, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
        }

        Card {
            Text("یادآور جدید", fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Picker("سال", (start.jy..start.jy + 3).map { it to Jalali.fa(it) }, jy, Modifier.weight(1.1f)) { jy = it }
                Picker("ماه", Jalali.MONTHS.mapIndexed { i, m -> (i + 1) to m }, jm, Modifier.weight(1.4f)) { jm = it }
                Picker("روز", (1..Jalali.monthLength(jy, jm)).map { it to Jalali.fa(it) }, jd.coerceAtMost(Jalali.monthLength(jy, jm)), Modifier.weight(1f)) { jd = it }
            }
            Spacer(Modifier.height(8.dp))
            Text("ساعت", color = Muted, fontSize = 13.sp)
            OutlinedButton(
                onClick = { TimePickerDialog(ctx, { _, h, m -> hour = h; minute = m }, hour, minute, true).show() },
                modifier = Modifier.fillMaxWidth()
            ) { Text(Jalali.fa("%02d:%02d".format(hour, minute)), color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(), minLines = 2,
                label = { Text("چه چیزی یادتان بیاید؟") }
            )
            val left = at - now
            Text(
                if (left > 0) "${Jalali.format(at)} (${Jalali.left(left)})" else "این زمان گذشته است؛ زمانی در آینده انتخاب کنید.",
                color = if (left > 0) Ink else AlarmRed, fontSize = 14.sp,
                modifier = Modifier.padding(vertical = 10.dp).fillMaxWidth()
                    .background(if (left > 0) SaffronSoft else Color.Transparent, RoundedCornerShape(8.dp)).padding(8.dp)
            )
            Button(
                onClick = {
                    when {
                        text.isBlank() -> Toast.makeText(ctx, "متن یادآور را بنویسید.", Toast.LENGTH_SHORT).show()
                        at <= System.currentTimeMillis() -> Toast.makeText(ctx, "زمانی در آینده انتخاب کنید.", Toast.LENGTH_SHORT).show()
                        else -> {
                            val r = Reminder(System.currentTimeMillis(), text.trim(), at)
                            ReminderStore.add(ctx, r)
                            AlarmScheduler.schedule(ctx, r)
                            Toast.makeText(ctx, "یادآور ثبت شد: " + Jalali.format(at), Toast.LENGTH_LONG).show()
                            text = ""; cmd = ""; info = ""
                            onAdded()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Ink)
            ) { Text("ثبت یادآور", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun ListScreen(reminders: List<Reminder>, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        item {
            Text("یادآورهای پیش رو", fontWeight = FontWeight.Bold, fontSize = 19.sp)
            if (reminders.isEmpty()) Text(
                "هنوز یادآوری ندارید. در بخش «یادآور جدید» یک دستور بنویسید یا بگویید.",
                color = Muted, modifier = Modifier.padding(top = 8.dp)
            )
        }
        items(reminders, key = { it.id }) { r ->
            Card {
                Row(verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text(r.text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(Jalali.format(r.at), color = Muted, fontSize = 14.sp)
                        Text(Jalali.left(r.at - now), color = Saffron, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    TextButton(onClick = {
                        AlarmScheduler.cancel(ctx, r.id); ReminderStore.delete(ctx, r.id); onChanged()
                    }) { Text("حذف", color = Muted) }
                }
            }
        }
    }
}

@Composable
fun StatusRow(title: String, ok: Boolean, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp)
            Text(if (ok) "فعال است" else "غیرفعال؛ برای آلارم مطمئن فعالش کنید", color = if (ok) OkGreen else AlarmRed, fontSize = 13.sp)
        }
        if (!ok) OutlinedButton(onClick = onClick) { Text(action, color = Ink, fontSize = 13.sp) }
    }
}

private fun openSettings(ctx: Context, action: String, withPackage: Boolean = true) {
    try {
        val i = Intent(action)
        if (withPackage) i.data = Uri.parse("package:" + ctx.packageName)
        ctx.startActivity(i)
    } catch (_: Exception) {
        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
    }
}

@Composable
fun SettingsScreen(resumeTick: Int) {
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }
    var voice by remember { mutableStateOf(Prefs.voice(ctx)) }

    // وضعیت مجوزها هر بار که برنامه دوباره باز شود به‌روز می‌شود
    val key = resumeTick + refresh
    val notifOk = remember(key) {
        Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }
    val exactOk = remember(key) {
        Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    }
    val fullOk = remember(key) {
        Build.VERSION.SDK_INT < 34 || ctx.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Card {
            Text("مجوزهای لازم برای آلارم", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            StatusRow("نمایش اعلان", notifOk, "اجازه بده") {
                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            StatusRow("آلارم دقیق سر ساعت", exactOk, "تنظیمات") {
                if (Build.VERSION.SDK_INT >= 31) openSettings(ctx, Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
            }
            StatusRow("صفحه تمام‌صفحه روی قفل گوشی", fullOk, "تنظیمات") {
                if (Build.VERSION.SDK_INT >= 34) openSettings(ctx, Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
            }
            OutlinedButton(
                onClick = { openSettings(ctx, Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, withPackage = false) },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            ) { Text("خارج کردن از بهینه‌سازی باتری", color = Ink) }
        }
        Card {
            Text("صدا", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("متن یادآور با صدا خوانده شود", Modifier.weight(1f))
                Switch(checked = voice, onCheckedChange = { voice = it; Prefs.setVoice(ctx, it) })
            }
            OutlinedButton(
                onClick = { openSettings(ctx, "com.android.settings.TTS_SETTINGS", withPackage = false) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("تنظیمات تبدیل متن به گفتار (صدای فارسی)", color = Ink) }
            Text(
                "برای خواندن متن به فارسی، در «Speech Services by Google» زبان فارسی را دانلود کنید.",
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }
        Card {
            Text("آزمایش", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Button(
                onClick = {
                    val r = Reminder(System.currentTimeMillis(), "این یک یادآور آزمایشی است", System.currentTimeMillis() + 10_000L)
                    ReminderStore.add(ctx, r); AlarmScheduler.schedule(ctx, r)
                    Toast.makeText(ctx, "آلارم آزمایشی ۱۰ ثانیه دیگر به صدا درمی‌آید. گوشی را قفل کنید و صبر کنید.", Toast.LENGTH_LONG).show()
                },
                modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Ink)
            ) { Text("آلارم آزمایشی ۱۰ ثانیه‌ای") }
        }
    }
}

@Composable
fun AboutScreen() {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        AppIcon(88)
        Spacer(Modifier.height(14.dp))
        Text("یادآور صوتی شمسی", fontWeight = FontWeight.Black, fontSize = 24.sp)
        Text("نسخه ۱٫۰", color = Muted)
        Spacer(Modifier.height(12.dp))
        Text("طراحی و توسعه", color = Muted)
        Text(DESIGNER, fontWeight = FontWeight.Black, fontSize = 22.sp, color = Saffron)
        Spacer(Modifier.height(16.dp))
        Text(
            "یادآور با تاریخ شمسی و دستور صوتی. سر موعد، صفحه قرمز آلارم حتی روی قفل گوشی باز می‌شود، متن یادآور خوانده می‌شود و تا معمای ریاضی حل نشود، یادآوری تکرار می‌شود.",
            textAlign = TextAlign.Center, color = Ink, lineHeight = 26.sp
        )
    }
}
