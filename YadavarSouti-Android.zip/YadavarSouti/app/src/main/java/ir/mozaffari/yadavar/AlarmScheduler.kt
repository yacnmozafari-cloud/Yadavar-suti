package ir.mozaffari.yadavar

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object AlarmScheduler {
    const val EXTRA_ID = "reminder_id"

    private fun code(id: Long) = (id xor (id ushr 32)).toInt()

    private fun operation(ctx: Context, id: Long): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code(id),
            Intent(ctx, AlarmReceiver::class.java).putExtra(EXTRA_ID, id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun schedule(ctx: Context, r: Reminder, at: Long = r.at) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val op = operation(ctx, r.id)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, op)
            return
        }
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        // setAlarmClock حتی در حالت Doze دقیق اجرا می‌شود و آیکون آلارم را در نوار وضعیت نشان می‌دهد
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), op)
    }

    fun cancel(ctx: Context, id: Long) {
        ctx.getSystemService(AlarmManager::class.java).cancel(operation(ctx, id))
    }

    /** پس از روشن شدن گوشی یا تغییر ساعت، همه یادآورها دوباره تنظیم می‌شوند */
    fun rescheduleAll(ctx: Context) {
        val now = System.currentTimeMillis()
        ReminderStore.pending(ctx).forEachIndexed { i, r ->
            schedule(ctx, r, if (r.at > now) r.at else now + 5_000L * (i + 1))
        }
    }
}
