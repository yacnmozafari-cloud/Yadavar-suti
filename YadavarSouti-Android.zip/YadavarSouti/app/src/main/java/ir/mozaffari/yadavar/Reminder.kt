package ir.mozaffari.yadavar

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Reminder(val id: Long, val text: String, val at: Long, val done: Boolean = false)

/** ذخیره یادآورها روی گوشی */
object ReminderStore {
    private const val PREF = "reminders"
    private const val KEY = "items"

    @Synchronized
    fun all(ctx: Context): List<Reminder> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Reminder(o.getLong("id"), o.getString("text"), o.getLong("at"), o.optBoolean("done", false))
        }.sortedBy { it.at }
    }

    @Synchronized
    private fun saveAll(ctx: Context, list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("at", it.at).put("done", it.done)) }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun pending(ctx: Context) = all(ctx).filter { !it.done }
    fun get(ctx: Context, id: Long) = all(ctx).firstOrNull { it.id == id }
    fun add(ctx: Context, r: Reminder) = saveAll(ctx, all(ctx) + r)
    fun delete(ctx: Context, id: Long) = saveAll(ctx, all(ctx).filter { it.id != id })

    fun markDone(ctx: Context, id: Long) {
        val monthAgo = System.currentTimeMillis() - 30L * 86_400_000L
        saveAll(ctx, all(ctx).map { if (it.id == id) it.copy(done = true) else it }.filter { !it.done || it.at > monthAgo })
    }
}

/** معمای ریاضی ساده برای خاموش کردن آلارم */
data class Puzzle(val question: String, val answer: Int) {
    companion object {
        fun make(): Puzzle {
            val r = java.util.Random()
            fun rnd(a: Int, b: Int) = a + r.nextInt(b - a + 1)
            return when (r.nextInt(3)) {
                0 -> { val a = rnd(12, 59); val b = rnd(11, 39); Puzzle("$a + $b", a + b) }
                1 -> { val a = rnd(3, 9); val b = rnd(4, 9); Puzzle("$a × $b", a * b) }
                else -> { val a = rnd(30, 80); val b = rnd(10, 29); Puzzle("$a − $b", a - b) }
            }
        }
    }
}
