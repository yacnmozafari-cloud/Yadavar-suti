package ir.mozaffari.yadavar

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/** کانال‌ها و اعلان‌های برنامه (به‌جز اعلان آلارم که در AlarmService است) */
object Notif {
    const val CH_PRE = "pre_channel"
    const val CH_DAILY = "daily_channel"
    private const val GROUP_DAILY = "daily_group"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH_PRE) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CH_PRE, "یادآوری پیش از موعد", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "اعلان چند دقیقه یا چند ساعت پیش از زمان یادآور"
                    enableVibration(true)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
            )
        }
        if (nm.getNotificationChannel(CH_DAILY) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CH_DAILY, "آیه، حدیث و شعر روز", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "هر روز یک آیه، یک حدیث، یک شعر و مناسبت امروز"
                }
            )
        }
    }

    private fun openApp(ctx: Context, req: Int): PendingIntent = PendingIntent.getActivity(
        ctx, req, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    @SuppressLint("MissingPermission")
    private fun post(ctx: Context, id: Int, n: Notification) {
        val m = NotificationManagerCompat.from(ctx)
        if (!m.areNotificationsEnabled()) return
        try { m.notify(id, n) } catch (_: SecurityException) {}
    }

    fun postPreAlert(ctx: Context, r: Reminder) {
        ensureChannels(ctx)
        val left = Jalali.left(r.at - System.currentTimeMillis())
        val b = NotificationCompat.Builder(ctx, CH_PRE)
            .setSmallIcon(R.drawable.ic_stat_alarm)
            .setContentTitle("یادآور به‌زودی — $left")
            .setContentText(r.text)
            .setSubText(Jalali.format(r.at))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, 11))
        val bmp = r.image?.let { Images.load(it, 900) }
        if (bmp != null) b.setLargeIcon(bmp).setStyle(NotificationCompat.BigPictureStyle().bigPicture(bmp).setSummaryText(r.text))
        else b.setStyle(NotificationCompat.BigTextStyle().bigText(r.text))
        post(ctx, 20_000 + (AlarmScheduler.code(r.id) and 0xFFFF), b.build())
    }

    private fun daily(ctx: Context, title: String, short: String, long: String) =
        NotificationCompat.Builder(ctx, CH_DAILY)
            .setSmallIcon(R.drawable.ic_stat_alarm)
            .setContentTitle(title)
            .setContentText(short)
            .setStyle(NotificationCompat.BigTextStyle().bigText(long))
            .setGroup(GROUP_DAILY)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, 12))
            .build()

    fun postDaily(ctx: Context) {
        ensureChannels(ctx)
        val jdn = Jalali.jdnFromMillis(System.currentTimeMillis())
        val c = Content.forJdn(jdn)
        val events = Events.forJdn(jdn, Prefs.hijriOffset(ctx))

        if (events.isNotEmpty()) {
            val t = events.joinToString("\n") { (if (it.holiday) "🔴 " else "• ") + it.title }
            post(ctx, 3004, daily(ctx, "مناسبت امروز — ${Jalali.dayTitle(jdn)}", events.first().title, t))
        }
        post(ctx, 3001, daily(ctx, "آیه روز — ${c.verse.ref}", c.verse.meaning,
            "${c.verse.arabic}\n\n${c.verse.meaning}\n(${c.verse.ref})"))
        post(ctx, 3002, daily(ctx, "حدیث روز — ${c.hadith.speaker}", c.hadith.meaning,
            "${c.hadith.arabic}\n\n${c.hadith.meaning}"))
        post(ctx, 3003, daily(ctx, "شعر روز — ${c.poem.poet}", c.poem.text.replace("\n", " / "),
            "${c.poem.text}\n\nمعنی: ${c.poem.meaning}"))

        val summary = NotificationCompat.Builder(ctx, CH_DAILY)
            .setSmallIcon(R.drawable.ic_stat_alarm)
            .setContentTitle("آیه، حدیث و شعر امروز")
            .setContentText(Jalali.dayTitle(jdn))
            .setGroup(GROUP_DAILY)
            .setGroupSummary(true)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, 12))
            .build()
        post(ctx, 3000, summary)
    }
}
