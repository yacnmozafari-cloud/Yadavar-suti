package ir.mozaffari.yadavar

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object AlarmScheduler {
    const val EXTRA_ID = "reminder_id"

    fun code(id: Long) = (id xor (id ushr 32)).toInt()

    private fun operation(ctx: Context, id: Long): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code(id),
            Intent(ctx, AlarmReceiver::class.java).putExtra(EXTRA_ID, id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun preOperation(ctx: Context, id: Long): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code(id),
            Intent(ctx, PreAlertReceiver::class.java).putExtra(EXTRA_ID, id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun canExact(am: AlarmManager) = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()

    fun schedule(ctx: Context, r: Reminder, at: Long = r.at) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val op = operation(ctx, r.id)
        if (!canExact(am)) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, op)
        } else {
            val show = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            // setAlarmClock حتی در حالت Doze دقیق اجرا می‌شود و آیکون آلارم را در نوار وضعیت نشان می‌دهد
            am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), op)
        }

        // اعلان زودتر از موعد (مثلاً ۱۵ دقیقه یا ۱ روز قبل)
        val preOp = preOperation(ctx, r.id)
        am.cancel(preOp)
        val preAt = at - r.pre * 60_000L
        if (r.pre > 0 && preAt > System.currentTimeMillis() + 5_000L) {
            if (canExact(am)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, preAt, preOp)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, preAt, preOp)
        }
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(operation(ctx, id))
        am.cancel(preOperation(ctx, id))
    }

    /** پس از روشن شدن گوشی یا تغییر ساعت، همه یادآورها دوباره تنظیم می‌شوند */
    fun rescheduleAll(ctx: Context) {
        val now = System.currentTimeMillis()
        ReminderStore.pending(ctx).forEachIndexed { i, r ->
            schedule(ctx, r, if (r.at > now) r.at else now + 5_000L * (i + 1))
        }
        DailyScheduler.schedule(ctx)
    }
}

/** زمان‌بندی اعلان روزانه آیه، حدیث و شعر */
object DailyScheduler {
    private fun op(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 9001, Intent(ctx, DailyReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = op(ctx)
        am.cancel(pi)
        if (!Prefs.daily(ctx)) return
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, Prefs.dailyHour(ctx))
            set(Calendar.MINUTE, Prefs.dailyMinute(ctx))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pi)
    }
}
