package ir.mozaffari.yadavar

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream

/** کپی تصویر انتخاب‌شده از گالری در حافظه داخلی برنامه و خواندن آن */
object Images {
    private fun sampleFor(w: Int, h: Int, maxPx: Int): Int {
        var s = 1
        while (maxOf(w, h) / (s * 2) >= maxPx) s *= 2
        return s
    }

    fun importFrom(ctx: Context, uri: Uri): String? = try {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, 1600) }
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        if (bmp == null) null else {
            val orientation = try {
                cr.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val out = if (deg == 0f) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
            val dir = File(ctx.filesDir, "images").apply { mkdirs() }
            val f = File(dir, "i_${System.currentTimeMillis()}.jpg")
            FileOutputStream(f).use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            f.absolutePath
        }
    } catch (_: Exception) { null }

    fun load(path: String, maxPx: Int): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, maxPx) })
    } catch (_: Exception) { null }
}

/** ضبط پیام صوتی با میکروفون در حافظه داخلی گوشی */
class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var file: File? = null
    val isRecording get() = rec != null

    fun start(): Boolean {
        val dir = File(ctx.filesDir, "voice").apply { mkdirs() }
        val f = File(dir, "v_${System.currentTimeMillis()}.m4a")
        val r = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
        return try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(96_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r; file = f
            true
        } catch (_: Exception) {
            r.release(); f.delete()
            false
        }
    }

    /** پایان ضبط؛ مسیر فایل یا null اگر ضبط خراب شد (مثلاً خیلی کوتاه بود) */
    fun stop(): String? {
        val r = rec ?: return null
        rec = null
        val f = file
        file = null
        return try {
            r.stop(); r.release()
            f?.absolutePath
        } catch (_: Exception) {
            r.release(); f?.delete()
            null
        }
    }

    fun release() { stop()?.let { File(it).delete() } }
}

/** پخش پیام صوتی در صفحه‌های برنامه */
class VoicePlayer {
    private var mp: MediaPlayer? = null
    val isPlaying get() = mp != null

    fun play(path: String, onDone: () -> Unit): Boolean {
        stop()
        return try {
            mp = MediaPlayer().apply {
                setDataSource(path)
                setOnCompletionListener { it.release(); mp = null; onDone() }
                prepare()
                start()
            }
            true
        } catch (_: Exception) { stop(); false }
    }

    fun stop() {
        mp?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        mp = null
    }
}
