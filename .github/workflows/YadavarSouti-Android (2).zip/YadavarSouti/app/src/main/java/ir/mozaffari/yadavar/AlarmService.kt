package ir.mozaffari.yadavar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Locale

/**
 * سرویس آلارم: زنگ، لرزش و خواندن متن یادآور را هر ۱۵ ثانیه تکرار می‌کند
 * تا وقتی که کاربر در صفحه آلارم معمای ریاضی را حل کند.
 */
class AlarmService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_START = "ir.mozaffari.yadavar.START"
        const val ACTION_DISMISS = "ir.mozaffari.yadavar.DISMISS"
        const val CHANNEL = "alarm_channel"
        const val NOTIF_ID = 1405
        private const val REPEAT_MS = 15_000L
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var voicePlayer: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var vibrator: Vibrator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var current: Reminder? = null
    private val queue = ArrayDeque<Long>()

    private val cycle = object : Runnable {
        override fun run() {
            ring()
            handler.postDelayed(this, REPEAT_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        createChannel()
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status == TextToSpeech.SUCCESS) {
            val r = t.setLanguage(Locale("fa", "IR"))
            ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { handler.post { afterSpeech() } }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { handler.post { afterSpeech() } }
            })
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISMISS -> {
                current?.let { ReminderStore.complete(this, it.id) }
                stopRinging()
                current = null
                val next = queue.removeFirstOrNull()
                if (next != null) startFor(next) else {
                    ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
            else -> {
                val id = intent?.getLongExtra(AlarmScheduler.EXTRA_ID, -1L) ?: -1L
                if (current == null) startFor(id)
                else if (id != current?.id && id !in queue) queue.addLast(id)
            }
        }
        return START_NOT_STICKY
    }

    private fun startFor(id: Long) {
        val r = ReminderStore.get(this, id)
        if (r == null || r.done) {
            if (current == null) {
                // سرویس پیش‌زمینه باید حتماً اعلان نشان دهد، حتی اگر یادآور حذف شده باشد
                val n = NotificationCompat.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_stat_alarm)
                    .setContentTitle("یادآور").setSilent(true).build()
                val t = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
                try { ServiceCompat.startForeground(this, NOTIF_ID, n, t) } catch (_: Exception) {}
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            return
        }
        current = r
        val notif = buildNotification(r)
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
        ServiceCompat.startForeground(this, NOTIF_ID, notif, type)

        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "yadavar:alarm").apply { acquire(30 * 60 * 1000L) }

        // تلاش برای باز کردن مستقیم صفحه آلارم؛ اگر سیستم اجازه ندهد، اعلان تمام‌صفحه آن را باز می‌کند
        try { startActivity(alarmIntent(r).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}

        startRingtone()
        startVibration()
        handler.removeCallbacks(cycle)
        handler.postDelayed(cycle, 6_000L)
    }

    private fun alarmIntent(r: Reminder) = Intent(this, AlarmActivity::class.java)
        .putExtra(AlarmScheduler.EXTRA_ID, r.id)
        .putExtra(AlarmActivity.EXTRA_TEXT, r.text)
        .putExtra(AlarmActivity.EXTRA_AT, r.at)

    private fun buildNotification(r: Reminder): Notification {
        val pi = PendingIntent.getActivity(
            this, 7, alarmIntent(r).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_alarm)
            .setContentTitle("یادآور")
            .setContentText(r.text)
            .setSubText("برای خاموش کردن، معما را حل کنید")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setAutoCancel(false)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
        val bmp = r.image?.let { Images.load(it, 900) }
        if (bmp != null) b.setLargeIcon(bmp).setStyle(NotificationCompat.BigPictureStyle().bigPicture(bmp).setSummaryText(r.text))
        return b.build()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "آلارم یادآورها", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "نمایش آلارم تمام‌صفحه یادآورها"
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(ch)
        }
    }

    private fun startRingtone() {
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        player?.release()
        player = try {
            MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@AlarmService, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (_: Exception) { null }
    }

    private fun resumeRingtone() { try { if (current != null) player?.start() } catch (_: Exception) {} }

    private fun startVibration() {
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            getSystemService(VibratorManager::class.java).defaultVibrator
        else getSystemService(Vibrator::class.java)
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 500), 0))
    }

    /** یک چرخه: مکث زنگ، خواندن متن، پخش پیام صوتی ضبط‌شده، سپس ادامه زنگ */
    private fun ring() {
        val r = current ?: return
        // اگر پیام صوتی هنوز در حال پخش است، این چرخه را رد کن تا قطع نشود
        if (try { voicePlayer?.isPlaying == true } catch (_: Exception) { false }) return
        val t = tts
        if (t != null && ttsReady && Prefs.voice(this)) {
            try { player?.pause() } catch (_: Exception) {}
            val params = Bundle().apply { putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_ALARM) }
            t.speak("یادآوری. ${r.text}", TextToSpeech.QUEUE_FLUSH, params, "reminder")
        } else {
            afterSpeech()
        }
    }

    private fun afterSpeech() {
        val r = current ?: return
        val path = r.voice
        if (path == null || !java.io.File(path).exists()) { resumeRingtone(); return }
        try { player?.pause() } catch (_: Exception) {}
        releaseVoice()
        voicePlayer = try {
            MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                setDataSource(path)
                setOnCompletionListener { handler.post { releaseVoice(); resumeRingtone() } }
                prepare()
                start()
            }
        } catch (_: Exception) { resumeRingtone(); null }
    }

    private fun releaseVoice() {
        voicePlayer?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        voicePlayer = null
    }

    private fun stopRinging() {
        handler.removeCallbacks(cycle)
        try { tts?.stop() } catch (_: Exception) {}
        releaseVoice()
        try { player?.stop(); player?.release() } catch (_: Exception) {}
        player = null
        vibrator?.cancel()
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    override fun onDestroy() {
        stopRinging()
        tts?.shutdown()
        super.onDestroy()
    }
}
