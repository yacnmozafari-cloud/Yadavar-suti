package ir.mozaffari.yadavar

import kotlin.math.ceil

/**
 * تاریخ قمری (هجری) با الگوریتم حسابی.
 * چون آغاز ماه قمری در ایران با رؤیت هلال اعلام می‌شود، ممکن است یک روز اختلاف پیش بیاید؛
 * برای همین در تنظیمات برنامه «تصحیح تاریخ قمری» گذاشته شده است.
 */
object Hijri {
    data class HDate(val y: Int, val m: Int, val d: Int)

    val MONTHS = listOf(
        "محرم", "صفر", "ربیع‌الاول", "ربیع‌الثانی", "جمادی‌الاول", "جمادی‌الثانی",
        "رجب", "شعبان", "رمضان", "شوال", "ذی‌القعده", "ذی‌الحجه"
    )

    fun toJdn(y: Int, m: Int, d: Int): Int =
        d + ceil(29.5 * (m - 1)).toInt() + (y - 1) * 354 + Math.floorDiv(3 + 11 * y, 30) + 1948439

    fun fromJdn(jdnIn: Int, offset: Int = 0): HDate {
        val jdn = jdnIn + offset
        val y = Math.floorDiv(30 * (jdn - 1948440) + 10646, 10631)
        val m = minOf(12, ceil((jdn - (29 + toJdn(y, 1, 1))).toDouble() / 29.5).toInt() + 1).coerceAtLeast(1)
        val d = jdn - toJdn(y, m, 1) + 1
        return HDate(y, m, d)
    }

    fun format(h: HDate): String = Jalali.fa("${h.d} ${MONTHS[h.m - 1]} ${h.y}")
}
