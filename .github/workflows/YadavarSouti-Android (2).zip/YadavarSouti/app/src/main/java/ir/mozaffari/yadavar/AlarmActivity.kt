package ir.mozaffari.yadavar

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** صفحه قرمز تمام‌صفحه آلارم؛ فقط با حل معما بسته می‌شود */
class AlarmActivity : ComponentActivity() {

    companion object {
        const val EXTRA_TEXT = "text"
        const val EXTRA_AT = "at"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        // دکمه بازگشت آلارم را نمی‌بندد
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {}
        })
        show()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        show()
    }

    private fun show() {
        val text = intent.getStringExtra(EXTRA_TEXT) ?: ""
        val at = intent.getLongExtra(EXTRA_AT, System.currentTimeMillis())
        val r = ReminderStore.get(this, intent.getLongExtra(AlarmScheduler.EXTRA_ID, -1L))
        setContent {
            AppTheme {
                AlarmScreen(text, at, r?.image, r?.voice != null) {
                    startService(Intent(this@AlarmActivity, AlarmService::class.java).setAction(AlarmService.ACTION_DISMISS))
                    finish()
                }
            }
        }
    }
}

@Composable
fun AlarmScreen(text: String, at: Long, image: String?, hasVoice: Boolean, onSolved: () -> Unit) {
    var puzzle by remember(text, at) { mutableStateOf(Puzzle.make()) }
    var answer by remember(text, at) { mutableStateOf("") }
    var wrong by remember(text, at) { mutableIntStateOf(0) }
    var message by remember(text, at) { mutableStateOf("") }

    fun check() {
        if (Jalali.en(answer.trim()).toIntOrNull() == puzzle.answer) {
            onSolved()
        } else {
            wrong++
            answer = ""
            if (wrong >= 3) {
                puzzle = Puzzle.make(); wrong = 0
                message = "سه جواب اشتباه؛ معمای تازه آمد."
            } else {
                message = "جواب درست نیست؛ دوباره حساب کنید. تا حل نشود یادآوری تکرار می‌شود."
            }
        }
    }

    Box(
        Modifier.fillMaxSize().background(AlarmRed).padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.widthIn(max = 440.dp).fillMaxWidth().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(96.dp).background(Color.White.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(painterResource(R.drawable.ic_stat_alarm), null, tint = Color.White, modifier = Modifier.size(48.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text(Jalali.format(at), color = Color.White.copy(alpha = 0.85f), fontSize = 15.sp)
            Text(
                text, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center, lineHeight = 44.sp, modifier = Modifier.padding(vertical = 8.dp)
            )
            if (image != null) AttachedImage(image, 220.dp, Modifier.padding(bottom = 10.dp))
            if (hasVoice) Text(
                "🎙 پیام صوتی شما پخش می‌شود", color = Color.White, fontSize = 15.sp,
                modifier = Modifier.padding(bottom = 10.dp)
            )
            Column(
                Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.18f), RoundedCornerShape(16.dp)).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("برای خاموش کردن، این معما را حل کنید:", color = Color.White, fontSize = 15.sp)
                Text(
                    Jalali.fa(puzzle.question) + " = ؟",
                    color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Black,
                    style = TextStyle(textDirection = TextDirection.Ltr),
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = answer,
                        onValueChange = { answer = it.take(4) },
                        singleLine = true,
                        textStyle = TextStyle(fontFamily = Vazir, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Ink),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { check() }),
                        colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White),
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { check() },
                        colors = ButtonDefaults.buttonColors(containerColor = Ink),
                        modifier = Modifier.height(56.dp)
                    ) { Text("خاموش کن", fontWeight = FontWeight.Bold) }
                }
                if (message.isNotEmpty()) {
                    Text(message, color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
    }
}
