package ir.mozaffari.yadavar

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

class MainActivity : ComponentActivity() {
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notif.ensureChannels(this)
        DailyScheduler.schedule(this)
        Thread { ReminderStore.cleanup(applicationContext) }.start()
        setContent { AppTheme { AppRoot(resumeTick.intValue) } }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
    }
}

private const val DESIGNER = "یاسین مظفری"
private const val VERSION = "۲٫۰"

private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

private fun granted(ctx: Context, perm: String) =
    ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

@Composable
fun AppRoot(resumeTick: Int) {
    val ctx = LocalContext.current
    var splash by remember { mutableStateOf(true) }
    var tab by remember { mutableIntStateOf(0) }
    var preset by remember { mutableStateOf<Jalali.JDate?>(null) }
    val items = remember { mutableStateListOf<Reminder>() }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        DailyScheduler.schedule(ctx)
    }

    fun reload() { items.clear(); items.addAll(ReminderStore.pending(ctx)) }
    LaunchedEffect(resumeTick) { reload() }
    LaunchedEffect(Unit) { delay(1700); splash = false }

    // بار اول: گرفتن اجازه نمایش اعلان از کاربر
    LaunchedEffect(splash) {
        if (!splash && !Prefs.askedPermissions(ctx)) {
            Prefs.setAskedPermissions(ctx)
            if (Build.VERSION.SDK_INT >= 33 && !granted(ctx, Manifest.permission.POST_NOTIFICATIONS)) {
                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    if (splash) { Splash(); return }

    Scaffold(
        containerColor = Paper,
        topBar = { AppBar() },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                val navColors = NavigationBarItemDefaults.colors(selectedIconColor = Saffron, selectedTextColor = Ink, indicatorColor = SaffronSoft)
                listOf(
                    Triple(R.drawable.ic_alarm, "یادآور", 0),
                    Triple(R.drawable.ic_calendar, "تقویم", 1),
                    Triple(R.drawable.ic_list, if (items.isEmpty()) "فهرست" else "فهرست (${Jalali.fa(items.size)})", 2),
                    Triple(R.drawable.ic_sound, "تنظیمات", 3),
                    Triple(R.drawable.ic_info, "درباره", 4),
                ).forEach { (icon, label, i) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i }, colors = navColors,
                        icon = { Icon(painterResource(icon), null) },
                        label = { Text(label, fontSize = 10.sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(preset) { preset = null; reload(); tab = 2 }
                1 -> CalendarScreen(items) { preset = it; tab = 0 }
                2 -> ListScreen(items) { reload() }
                3 -> SettingsScreen(resumeTick)
                else -> AboutScreen()
            }
        }
    }
}

@Composable
fun AppIcon(size: Int) {
    Box(
        Modifier.size(size.dp).background(Ink, RoundedCornerShape((size / 4).dp)),
        contentAlignment = Alignment.Center
    ) { Icon(painterResource(R.drawable.ic_stat_alarm), null, tint = Saffron, modifier = Modifier.size((size * 0.6).dp)) }
}

@Composable
fun Splash() {
    Box(Modifier.fillMaxSize().background(Ink), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            AppIcon(104)
            Spacer(Modifier.height(18.dp))
            Text("یادآور صوتی شمسی", color = Paper, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text("طراحی و توسعه: $DESIGNER", color = Saffron, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
fun AppBar() {
    Row(
        Modifier.fillMaxWidth().background(Paper).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(38)
        Spacer(Modifier.width(10.dp))
        Column {
            Text("یادآور صوتی شمسی", fontWeight = FontWeight.Black, fontSize = 17.sp)
            Text("طراحی: $DESIGNER", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun Card(content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 8.dp)
            .background(Color.White, RoundedCornerShape(14.dp))
            .border(1.dp, Line, RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) { content() }
}

@Composable
fun Picker(label: String, options: List<Pair<Int, String>>, selected: Int, modifier: Modifier = Modifier, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column(modifier) {
        Text(label, color = Muted, fontSize = 13.sp)
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(8.dp)) {
                Text(options.firstOrNull { it.first == selected }?.second ?: "-", color = Ink, maxLines = 1)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { (v, t) -> DropdownMenuItem(text = { Text(t) }, onClick = { onSelect(v); open = false }) }
            }
        }
    }
}

/** نمایش تصویر پیوست‌شده از حافظه داخلی */
@Composable
fun AttachedImage(path: String, height: Dp, modifier: Modifier = Modifier) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { Images.load(path, 1080)?.asImageBitmap() }
    }
    bmp?.let {
        Image(
            it, null, contentScale = ContentScale.Crop,
            modifier = modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(12.dp))
        )
    }
}

@Composable
fun IconAction(icon: Int, text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
        Icon(painterResource(icon), null, tint = Ink, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(text, color = Ink, fontSize = 13.sp, maxLines = 1)
    }
}

private fun mmss(sec: Long) = Jalali.fa("%02d:%02d".format(sec / 60, sec % 60))

// ========================= یادآور جدید =========================

@Composable
fun HomeScreen(preset: Jalali.JDate?, onAdded: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(500) } }

    val start = remember { Jalali.fromMillis(System.currentTimeMillis()) }
    val startCal = remember { Calendar.getInstance().apply { add(Calendar.MINUTE, 10) } }
    val first = preset ?: start
    var jy by remember { mutableIntStateOf(first.jy) }
    var jm by remember { mutableIntStateOf(first.jm) }
    var jd by remember { mutableIntStateOf(first.jd) }
    var hour by remember { mutableIntStateOf(if (preset != null) 9 else startCal.get(Calendar.HOUR_OF_DAY)) }
    var minute by remember { mutableIntStateOf(if (preset != null) 0 else startCal.get(Calendar.MINUTE)) }
    var text by remember { mutableStateOf("") }
    var cmd by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("") }
    var repeat by remember { mutableIntStateOf(Repeat.NONE) }
    var pre by remember { mutableIntStateOf(0) }

    // پیوست‌ها
    val recorder = remember { VoiceRecorder(ctx) }
    val player = remember { VoicePlayer() }
    var recording by remember { mutableStateOf(false) }
    var recStart by remember { mutableLongStateOf(0L) }
    var voicePath by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf(false) }
    var imagePath by remember { mutableStateOf<String?>(null) }
    DisposableEffect(Unit) { onDispose { recorder.release(); player.stop() } }

    fun startRec() {
        player.stop(); playing = false
        if (recorder.start()) { recording = true; recStart = System.currentTimeMillis() }
        else toast(ctx, "ضبط صدا شروع نشد؛ شاید برنامه دیگری از میکروفون استفاده می‌کند.")
    }

    fun stopRec() {
        val p = recorder.stop()
        recording = false
        if (p != null) { voicePath?.let { File(it).delete() }; voicePath = p }
        else toast(ctx, "ضبط خیلی کوتاه بود؛ دوباره امتحان کنید.")
    }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRec() else toast(ctx, "برای ضبط پیام صوتی باید اجازه میکروفون را بدهید.")
    }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val p = withContext(Dispatchers.IO) { Images.importFrom(ctx, uri) }
            if (p != null) { imagePath?.let { File(it).delete() }; imagePath = p }
            else toast(ctx, "این تصویر قابل خواندن نبود؛ تصویر دیگری انتخاب کنید.")
        }
    }

    fun applyCommand() {
        val r = CommandParser.parse(cmd)
        r.date?.let { jy = it.jy; jm = it.jm; jd = it.jd.coerceIn(1, Jalali.monthLength(it.jy, it.jm)) }
        if (r.hour != null) { hour = r.hour; minute = r.minute ?: 0 }
        if (r.text.isNotEmpty()) text = r.text
        val miss = buildList { if (r.date == null) add("تاریخ"); if (r.hour == null) add("ساعت"); if (r.text.isEmpty()) add("متن") }
        info = if (miss.isEmpty()) "دستور خوانده شد. بررسی کنید و «ثبت یادآور» را بزنید."
        else "${miss.joinToString(" و ")} در دستور پیدا نشد؛ آن را در فرم پایین کامل کنید."
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val list = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        if (!list.isNullOrEmpty()) { cmd = list[0]; applyCommand() }
    }
    fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "دستور یادآور را بگویید")
        try { speech.launch(i) } catch (_: ActivityNotFoundException) {
            info = "تشخیص گفتار روی این گوشی نصب نیست؛ برنامه Google را نصب کنید یا دستور را تایپ کنید."
        }
    }

    val at = Jalali.toMillis(jy, jm, jd.coerceAtMost(Jalali.monthLength(jy, jm)), hour, minute)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        // ساعت زنده
        Column(Modifier.padding(vertical = 10.dp)) {
            Text("ساعت و تاریخ امروز", color = Muted, fontSize = 14.sp)
            Text(Jalali.clock(now), fontSize = 72.sp, fontWeight = FontWeight.Black, lineHeight = 80.sp)
            Text(Jalali.today(now), fontSize = 19.sp, fontWeight = FontWeight.Bold)
            HorizontalDivider(Modifier.padding(top = 14.dp), thickness = 2.dp, color = Ink)
        }

        Card {
            Text("دستور بدهید", fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text("بنویسید یا با میکروفون بگویید چه چیزی، چه روزی و چه ساعتی یادتان بیاید.", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = cmd, onValueChange = { cmd = it }, modifier = Modifier.weight(1f),
                    placeholder = { Text("مثلاً: ۱۵ آبان ساعت ۸:۳۰ صبح جلسه با مدیر") }
                )
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(56.dp).background(Saffron, CircleShape), contentAlignment = Alignment.Center) {
                    TextButton(onClick = { listen() }, modifier = Modifier.fillMaxSize(), shape = CircleShape) {
                        Icon(painterResource(R.drawable.ic_mic), "گفتن دستور", tint = Ink)
                    }
                }
            }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("۱۰ دقیقه دیگه ", "فردا ساعت ۸ صبح ", "امشب ساعت ۱۰ ").forEach { c ->
                    OutlinedButton(onClick = { cmd = c; applyCommand() }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)) {
                        Text(c.trim(), fontSize = 12.sp, color = Muted)
                    }
                }
            }
            OutlinedButton(onClick = { applyCommand() }, modifier = Modifier.padding(top = 6.dp)) { Text("خواندن دستور", color = Ink) }
            if (info.isNotEmpty()) Text(info, color = OkGreen, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
        }

        Card {
            Text("یادآور جدید", fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Picker("سال", (minOf(start.jy, jy)..maxOf(start.jy + 3, jy)).map { it to Jalali.fa(it) }, jy, Modifier.weight(1.1f)) { jy = it }
                Picker("ماه", Jalali.MONTHS.mapIndexed { i, m -> (i + 1) to m }, jm, Modifier.weight(1.4f)) { jm = it }
                Picker("روز", (1..Jalali.monthLength(jy, jm)).map { it to Jalali.fa(it) }, jd.coerceAtMost(Jalali.monthLength(jy, jm)), Modifier.weight(1f)) { jd = it }
            }
            Spacer(Modifier.height(8.dp))
            Text("ساعت", color = Muted, fontSize = 13.sp)
            OutlinedButton(
                onClick = { TimePickerDialog(ctx, { _, h, m -> hour = h; minute = m }, hour, minute, true).show() },
                modifier = Modifier.fillMaxWidth()
            ) { Text(Jalali.fa("%02d:%02d".format(hour, minute)), color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(), minLines = 2,
                label = { Text("یادداشت متنی: چه چیزی یادتان بیاید؟") }
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Picker("تکرار", Repeat.OPTIONS, repeat, Modifier.weight(1f)) { repeat = it }
                Picker("اعلان زودتر", PRE_OPTIONS, pre, Modifier.weight(1f)) { pre = it }
            }

            // ---------- یادداشت صوتی ----------
            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = Line)
            Text("یادداشت صوتی", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("پیام خودتان را با صدای خودتان ضبط کنید؛ سر موعد پخش می‌شود.", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            when {
                recording -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(12.dp).background(AlarmRed, CircleShape))
                    Spacer(Modifier.width(8.dp))
                    Text("در حال ضبط… " + mmss((now - recStart).coerceAtLeast(0) / 1000), color = AlarmRed, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Button(onClick = { stopRec() }, colors = ButtonDefaults.buttonColors(containerColor = AlarmRed)) {
                        Icon(painterResource(R.drawable.ic_stop), null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("پایان ضبط")
                    }
                }
                voicePath != null -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconAction(if (playing) R.drawable.ic_stop else R.drawable.ic_play, if (playing) "توقف" else "پخش") {
                        if (playing) {
                            player.stop(); playing = false
                        } else {
                            val p = voicePath
                            if (p != null) playing = player.play(p, onDone = { playing = false })
                        }
                    }
                    IconAction(R.drawable.ic_mic, "ضبط دوباره") {
                        if (granted(ctx, Manifest.permission.RECORD_AUDIO)) startRec() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                    TextButton(onClick = { player.stop(); playing = false; voicePath?.let { File(it).delete() }; voicePath = null }) {
                        Text("حذف", color = AlarmRed)
                    }
                }
                else -> IconAction(R.drawable.ic_mic, "ضبط پیام صوتی", Modifier.fillMaxWidth()) {
                    if (granted(ctx, Manifest.permission.RECORD_AUDIO)) startRec() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }

            // ---------- تصویر ----------
            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = Line)
            Text("تصویر", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("یک عکس از گالری انتخاب کنید؛ سر موعد روی صفحه آلارم و اعلان نمایش داده می‌شود.", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            val img = imagePath
            if (img != null) {
                AttachedImage(img, 180.dp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                    IconAction(R.drawable.ic_image, "تغییر تصویر") {
                        pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    TextButton(onClick = { File(img).delete(); imagePath = null }) { Text("حذف تصویر", color = AlarmRed) }
                }
            } else {
                IconAction(R.drawable.ic_image, "افزودن تصویر از گالری", Modifier.fillMaxWidth()) {
                    pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
            }

            val left = at - now
            Text(
                if (left > 0) "${Jalali.format(at)} (${Jalali.left(left)})" else "این زمان گذشته است؛ زمانی در آینده انتخاب کنید.",
                color = if (left > 0) Ink else AlarmRed, fontSize = 14.sp,
                modifier = Modifier.padding(vertical = 12.dp).fillMaxWidth()
                    .background(if (left > 0) SaffronSoft else Color.Transparent, RoundedCornerShape(8.dp)).padding(8.dp)
            )
            Button(
                onClick = {
                    if (recording) stopRec()
                    when {
                        text.isBlank() && voicePath == null -> toast(ctx, "یادداشت متنی بنویسید یا پیام صوتی ضبط کنید.")
                        at <= System.currentTimeMillis() -> toast(ctx, "زمانی در آینده انتخاب کنید.")
                        else -> {
                            player.stop(); playing = false
                            val r = Reminder(
                                id = System.currentTimeMillis(),
                                text = text.trim().ifEmpty { "پیام صوتی" },
                                at = at, voice = voicePath, image = imagePath, repeat = repeat, pre = pre,
                            )
                            ReminderStore.add(ctx, r)
                            AlarmScheduler.schedule(ctx, r)
                            toast(ctx, "یادآور ثبت شد: " + Jalali.format(at))
                            text = ""; cmd = ""; info = ""; voicePath = null; imagePath = null
                            onAdded()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Ink)
            ) { Text("ثبت یادآور", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ========================= تقویم =========================

@Composable
fun CalendarScreen(reminders: List<Reminder>, onAddForDate: (Jalali.JDate) -> Unit) {
    val ctx = LocalContext.current
    val off = remember { Prefs.hijriOffset(ctx) }
    val todayJdn = remember { Jalali.jdnFromMillis(System.currentTimeMillis()) }
    val todayJ = remember { Jalali.fromJdn(todayJdn) }
    var vy by remember { mutableIntStateOf(todayJ.jy) }
    var vm by remember { mutableIntStateOf(todayJ.jm) }
    var sel by remember { mutableIntStateOf(todayJdn) }
    val reminderDays = remember(reminders.toList()) { reminders.map { Jalali.jdnFromMillis(it.at) }.toSet() }

    val firstJdn = Jalali.jdn(vy, vm, 1)
    val len = Jalali.monthLength(vy, vm)
    val lastJdn = firstJdn + len - 1
    val lead = Jalali.weekIndex(firstJdn)

    fun move(n: Int) {
        val t = Jalali.addMonths(Jalali.JDate(vy, vm, 1), n)
        vy = t.jy; vm = t.jm
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        Card {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { move(-1) }) { Text("‹ ماه قبل", color = Ink) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(Jalali.fa("${Jalali.MONTHS[vm - 1]} $vy"), fontWeight = FontWeight.Black, fontSize = 20.sp)
                    val h1 = Hijri.fromJdn(firstJdn, off); val h2 = Hijri.fromJdn(lastJdn, off)
                    val g1 = Jalali.gregFromJdn(firstJdn); val g2 = Jalali.gregFromJdn(lastJdn)
                    Text(
                        Jalali.fa("${Hijri.MONTHS[h1.m - 1]} – ${Hijri.MONTHS[h2.m - 1]} ${h2.y}"),
                        color = Muted, fontSize = 12.sp
                    )
                    Text(
                        Jalali.fa("${Jalali.G_MONTHS[g1[1] - 1]} – ${Jalali.G_MONTHS[g2[1] - 1]} ${g2[0]}"),
                        color = Muted, fontSize = 12.sp
                    )
                }
                TextButton(onClick = { move(1) }) { Text("ماه بعد ›", color = Ink) }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                listOf("ش", "ی", "د", "س", "چ", "پ", "ج").forEachIndexed { i, w ->
                    Text(
                        w, modifier = Modifier.weight(1f), textAlign = TextAlign.Center,
                        color = if (i == 6) AlarmRed else Muted, fontWeight = FontWeight.Bold, fontSize = 13.sp
                    )
                }
            }
            val rows = (lead + len + 6) / 7
            for (r in 0 until rows) {
                Row(Modifier.fillMaxWidth()) {
                    for (c in 0 until 7) {
                        val day = r * 7 + c - lead + 1
                        if (day in 1..len) {
                            val jdn = firstJdn + day - 1
                            val events = Events.forJdn(jdn, off)
                            DayCell(
                                day = day, jdn = jdn, off = off,
                                isToday = jdn == todayJdn, isSelected = jdn == sel,
                                holiday = c == 6 || events.any { it.holiday },
                                hasEvent = events.isNotEmpty(), hasReminder = jdn in reminderDays,
                                modifier = Modifier.weight(1f)
                            ) { sel = jdn }
                        } else Spacer(Modifier.weight(1f))
                    }
                }
            }
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(Saffron, CircleShape))
                Text(" مناسبت   ", fontSize = 12.sp, color = Muted)
                Box(Modifier.size(8.dp).background(OkGreen, CircleShape))
                Text(" یادآور   ", fontSize = 12.sp, color = Muted)
                Text("قرمز = تعطیل", fontSize = 12.sp, color = AlarmRed)
                Spacer(Modifier.weight(1f))
                if (sel != todayJdn || vy != todayJ.jy || vm != todayJ.jm) {
                    TextButton(onClick = { sel = todayJdn; vy = todayJ.jy; vm = todayJ.jm }) { Text("امروز", color = Saffron, fontWeight = FontWeight.Bold) }
                }
            }
        }

        // جزئیات روز انتخاب‌شده
        Card {
            val events = Events.forJdn(sel, off)
            val holiday = Jalali.weekIndex(sel) == 6 || events.any { it.holiday }
            Text(Jalali.dayTitle(sel), fontWeight = FontWeight.Black, fontSize = 19.sp, color = if (holiday) AlarmRed else Ink)
            Text("قمری: " + Hijri.format(Hijri.fromJdn(sel, off)), color = Muted, fontSize = 14.sp)
            Text("میلادی: " + Jalali.gregTitle(sel), color = Muted, fontSize = 14.sp)
            if (holiday) Text("تعطیل رسمی", color = AlarmRed, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(8.dp))
            if (events.isEmpty()) Text("مناسبت خاصی ثبت نشده است.", color = Muted, fontSize = 14.sp)
            events.forEach {
                Text(
                    (if (it.holiday) "● " else "○ ") + it.title,
                    color = if (it.holiday) AlarmRed else Ink, fontSize = 15.sp, modifier = Modifier.padding(vertical = 2.dp)
                )
            }
            val dayRem = reminders.filter { Jalali.jdnFromMillis(it.at) == sel }
            if (dayRem.isNotEmpty()) {
                HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Line)
                Text("یادآورهای این روز", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                dayRem.forEach { Text("⏰ ${Jalali.clock(it.at)} — ${it.text}", fontSize = 14.sp, color = OkGreen, modifier = Modifier.padding(vertical = 2.dp)) }
            }
            if (sel >= todayJdn) {
                Button(
                    onClick = { onAddForDate(Jalali.fromJdn(sel)) },
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Ink)
                ) { Text("یادآور برای این روز", fontWeight = FontWeight.Bold) }
            }
        }

        DailyContentCard(todayJdn)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun DayCell(
    day: Int, jdn: Int, off: Int, isToday: Boolean, isSelected: Boolean, holiday: Boolean,
    hasEvent: Boolean, hasReminder: Boolean, modifier: Modifier, onClick: () -> Unit,
) {
    val h = Hijri.fromJdn(jdn, off)
    val g = Jalali.gregFromJdn(jdn)
    val bg = when { isSelected -> Ink; holiday -> Color(0xFFFCECEC); else -> Color.Transparent }
    val main = when { isSelected -> Color.White; holiday -> AlarmRed; else -> Ink }
    val sub = if (isSelected) Color.White.copy(alpha = 0.75f) else Muted
    Column(
        modifier.padding(2.dp).aspectRatio(0.78f)
            .clip(RoundedCornerShape(10.dp))
            .background(bg)
            .border(if (isToday) 2.dp else 0.dp, if (isToday) Saffron else Color.Transparent, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(vertical = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(Jalali.fa(day), color = main, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(Jalali.fa(h.d), color = sub, fontSize = 9.sp)
            Text(g[2].toString(), color = sub, fontSize = 9.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.height(6.dp)) {
            if (hasEvent) Box(Modifier.size(5.dp).background(Saffron, CircleShape))
            if (hasReminder) Box(Modifier.size(5.dp).background(OkGreen, CircleShape))
        }
    }
}

@Composable
fun DailyContentCard(jdn: Int) {
    val c = remember(jdn) { Content.forJdn(jdn) }
    Card {
        Text("آیه، حدیث و شعر امروز", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(10.dp))
        Text("📖 آیه روز", color = Saffron, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(c.verse.arabic, fontSize = 20.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
        Text(c.verse.meaning, fontSize = 15.sp, lineHeight = 24.sp)
        Text(c.verse.ref, color = Muted, fontSize = 12.sp)
        HorizontalDivider(Modifier.padding(vertical = 10.dp), color = Line)
        Text("💬 حدیث روز — ${c.hadith.speaker}", color = Saffron, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(c.hadith.arabic, fontSize = 18.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
        Text(c.hadith.meaning, fontSize = 15.sp, lineHeight = 24.sp)
        HorizontalDivider(Modifier.padding(vertical = 10.dp), color = Line)
        Text("🌿 شعر روز — ${c.poem.poet}", color = Saffron, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(c.poem.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
        Text("معنی: " + c.poem.meaning, fontSize = 15.sp, lineHeight = 24.sp)
    }
}

// ========================= فهرست =========================

@Composable
fun ListScreen(reminders: List<Reminder>, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val player = remember { VoicePlayer() }
    var playingId by remember { mutableLongStateOf(-1L) }
    DisposableEffect(Unit) { onDispose { player.stop() } }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        item {
            Text("یادآورهای پیش رو", fontWeight = FontWeight.Bold, fontSize = 19.sp)
            if (reminders.isEmpty()) Text(
                "هنوز یادآوری ندارید. در بخش «یادآور» یک دستور بنویسید یا بگویید.",
                color = Muted, modifier = Modifier.padding(top = 8.dp)
            )
        }
        items(reminders, key = { it.id }) { r ->
            Card {
                Row(verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text(r.text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(Jalali.format(r.at), color = Muted, fontSize = 14.sp)
                        Text(Jalali.left(r.at - now), color = Saffron, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        val extra = buildList {
                            if (r.repeat != Repeat.NONE) add("🔁 " + Repeat.label(r.repeat))
                            if (r.pre > 0) add("🔔 " + (PRE_OPTIONS.firstOrNull { it.first == r.pre }?.second ?: ""))
                        }
                        if (extra.isNotEmpty()) Text(extra.joinToString("   "), color = Muted, fontSize = 13.sp)
                    }
                    TextButton(onClick = {
                        if (playingId == r.id) { player.stop(); playingId = -1L }
                        AlarmScheduler.cancel(ctx, r.id); ReminderStore.delete(ctx, r.id); onChanged()
                    }) { Text("حذف", color = Muted) }
                }
                r.image?.let { AttachedImage(it, 150.dp, Modifier.padding(top = 8.dp)) }
                r.voice?.let { path ->
                    val isPlaying = playingId == r.id
                    IconAction(
                        if (isPlaying) R.drawable.ic_stop else R.drawable.ic_play,
                        if (isPlaying) "توقف پیام صوتی" else "پخش پیام صوتی",
                        Modifier.padding(top = 8.dp)
                    ) {
                        if (isPlaying) {
                            player.stop(); playingId = -1L
                        } else {
                            val ok = player.play(path, onDone = { playingId = -1L })
                            if (ok) playingId = r.id else toast(ctx, "فایل صوتی پیدا نشد.")
                        }
                    }
                }
            }
        }
    }
}

// ========================= تنظیمات =========================

@Composable
fun StatusRow(title: String, ok: Boolean, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp)
            Text(if (ok) "فعال است" else "غیرفعال؛ برای کارکرد کامل فعالش کنید", color = if (ok) OkGreen else AlarmRed, fontSize = 13.sp)
        }
        if (!ok) OutlinedButton(onClick = onClick) { Text(action, color = Ink, fontSize = 13.sp) }
    }
}

private fun openSettings(ctx: Context, action: String, withPackage: Boolean = true) {
    try {
        val i = Intent(action)
        if (withPackage) i.data = Uri.parse("package:" + ctx.packageName)
        ctx.startActivity(i)
    } catch (_: Exception) {
        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
    }
}

@Composable
fun SettingsScreen(resumeTick: Int) {
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        refresh++
        DailyScheduler.schedule(ctx)
    }
    var voice by remember { mutableStateOf(Prefs.voice(ctx)) }
    var daily by remember { mutableStateOf(Prefs.daily(ctx)) }
    var dh by remember { mutableIntStateOf(Prefs.dailyHour(ctx)) }
    var dm by remember { mutableIntStateOf(Prefs.dailyMinute(ctx)) }
    var hOff by remember { mutableIntStateOf(Prefs.hijriOffset(ctx)) }

    // وضعیت مجوزها هر بار که برنامه دوباره باز شود به‌روز می‌شود
    val key = resumeTick + refresh
    val notifOk = remember(key) {
        Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS)
    }
    val micOk = remember(key) { granted(ctx, Manifest.permission.RECORD_AUDIO) }
    val exactOk = remember(key) {
        Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    }
    val fullOk = remember(key) {
        Build.VERSION.SDK_INT < 34 || ctx.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Card {
            Text("مجوزهای برنامه", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            StatusRow("نمایش اعلان", notifOk, "اجازه بده") {
                if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            StatusRow("میکروفون (برای یادداشت صوتی)", micOk, "اجازه بده") {
                permLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
            StatusRow("آلارم دقیق سر ساعت", exactOk, "تنظیمات") {
                if (Build.VERSION.SDK_INT >= 31) openSettings(ctx, Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
            }
            StatusRow("صفحه تمام‌صفحه روی قفل گوشی", fullOk, "تنظیمات") {
                if (Build.VERSION.SDK_INT >= 34) openSettings(ctx, Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
            }
            OutlinedButton(
                onClick = { openSettings(ctx, Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, withPackage = false) },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            ) { Text("خارج کردن از بهینه‌سازی باتری", color = Ink) }
            Text(
                "انتخاب تصویر با پنجره امن گالری خود اندروید انجام می‌شود؛ برنامه فقط به عکسی که خودتان انتخاب می‌کنید دسترسی دارد. صداها و تصویرها در حافظه داخلی گوشی ذخیره می‌شوند.",
                color = Muted, fontSize = 13.sp, lineHeight = 21.sp, modifier = Modifier.padding(top = 8.dp)
            )
        }
        Card {
            Text("اعلان روزانه", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("هر روز یک آیه، یک حدیث، یک شعر با معنی و مناسبت امروز", Modifier.weight(1f), fontSize = 14.sp)
                Switch(checked = daily, onCheckedChange = { daily = it; Prefs.setDaily(ctx, it); DailyScheduler.schedule(ctx) })
            }
            if (daily) {
                Text("ساعت ارسال اعلان", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                OutlinedButton(
                    onClick = {
                        TimePickerDialog(ctx, { _, h, m ->
                            dh = h; dm = m; Prefs.setDailyTime(ctx, h, m); DailyScheduler.schedule(ctx)
                        }, dh, dm, true).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(Jalali.fa("%02d:%02d".format(dh, dm)), color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            }
            OutlinedButton(
                onClick = {
                    if (!notifOk && Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else { Notif.postDaily(ctx); toast(ctx, "اعلان امروز فرستاده شد؛ نوار اعلان را پایین بکشید.") }
                },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            ) { Text("نمایش اعلان امروز (آزمایش)", color = Ink) }
        }
        Card {
            Text("تقویم", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(
                "آغاز ماه‌های قمری در ایران با رؤیت هلال اعلام می‌شود. اگر تاریخ قمری یک روز با تقویم رسمی فرق داشت، اینجا اصلاحش کنید.",
                color = Muted, fontSize = 13.sp, lineHeight = 21.sp
            )
            Picker(
                "تصحیح تاریخ قمری",
                listOf(-2 to "۲ روز عقب", -1 to "۱ روز عقب", 0 to "بدون تصحیح", 1 to "۱ روز جلو", 2 to "۲ روز جلو"),
                hOff, Modifier.fillMaxWidth().padding(top = 6.dp)
            ) { hOff = it; Prefs.setHijriOffset(ctx, it) }
            Text(
                "امروز به قمری: " + Hijri.format(Hijri.fromJdn(Jalali.jdnFromMillis(System.currentTimeMillis()), hOff)),
                fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }
        Card {
            Text("صدا", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("متن یادآور با صدا خوانده شود", Modifier.weight(1f))
                Switch(checked = voice, onCheckedChange = { voice = it; Prefs.setVoice(ctx, it) })
            }
            OutlinedButton(
                onClick = { openSettings(ctx, "com.android.settings.TTS_SETTINGS", withPackage = false) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("تنظیمات تبدیل متن به گفتار (صدای فارسی)", color = Ink) }
            Text(
                "برای خواندن متن به فارسی، در «Speech Services by Google» زبان فارسی را دانلود کنید. پیام صوتی ضبط‌شده همیشه پخش می‌شود.",
                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }
        Card {
            Text("آزمایش", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Button(
                onClick = {
                    val r = Reminder(System.currentTimeMillis(), "این یک یادآور آزمایشی است", System.currentTimeMillis() + 10_000L)
                    ReminderStore.add(ctx, r); AlarmScheduler.schedule(ctx, r)
                    toast(ctx, "آلارم آزمایشی ۱۰ ثانیه دیگر به صدا درمی‌آید. گوشی را قفل کنید و صبر کنید.")
                },
                modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Ink)
            ) { Text("آلارم آزمایشی ۱۰ ثانیه‌ای") }
        }
    }
}

// ========================= درباره =========================

@Composable
fun AboutScreen() {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        AppIcon(88)
        Spacer(Modifier.height(14.dp))
        Text("یادآور صوتی شمسی", fontWeight = FontWeight.Black, fontSize = 24.sp)
        Text("نسخه $VERSION", color = Muted)
        Spacer(Modifier.height(12.dp))
        Text("طراحی و توسعه", color = Muted)
        Text(DESIGNER, fontWeight = FontWeight.Black, fontSize = 22.sp, color = Saffron)
        Spacer(Modifier.height(16.dp))
        Text(
            "یادآور با تاریخ شمسی، یادداشت متنی، پیام صوتی و تصویر. سر موعد، صفحه قرمز آلارم حتی روی قفل گوشی باز می‌شود، متن خوانده و پیام صوتی شما پخش می‌شود و تا معمای ریاضی حل نشود، یادآوری تکرار می‌شود.\n\n" +
                "تقویم کامل شمسی با تاریخ قمری و میلادی، تعطیلات رسمی و مناسبت‌ها؛ و هر روز یک آیه، یک حدیث و یک شعر با معنی.",
            textAlign = TextAlign.Center, color = Ink, lineHeight = 26.sp,
            style = TextStyle(textDirection = TextDirection.Rtl)
        )
    }
}
