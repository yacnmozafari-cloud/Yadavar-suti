package ir.mozaffari.yadavar

import android.content.Context

object Prefs {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun voice(ctx: Context) = sp(ctx).getBoolean("voice", true)
    fun setVoice(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("voice", v).apply()

    /** اعلان روزانه آیه، حدیث و شعر */
    fun daily(ctx: Context) = sp(ctx).getBoolean("daily", true)
    fun setDaily(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("daily", v).apply()
    fun dailyHour(ctx: Context) = sp(ctx).getInt("daily_h", 8)
    fun dailyMinute(ctx: Context) = sp(ctx).getInt("daily_m", 0)
    fun setDailyTime(ctx: Context, h: Int, m: Int) = sp(ctx).edit().putInt("daily_h", h).putInt("daily_m", m).apply()

    /** تصحیح تاریخ قمری (روز) */
    fun hijriOffset(ctx: Context) = sp(ctx).getInt("hijri_offset", 0)
    fun setHijriOffset(ctx: Context, v: Int) = sp(ctx).edit().putInt("hijri_offset", v).apply()

    fun askedPermissions(ctx: Context) = sp(ctx).getBoolean("asked_perm", false)
    fun setAskedPermissions(ctx: Context) = sp(ctx).edit().putBoolean("asked_perm", true).apply()
}
