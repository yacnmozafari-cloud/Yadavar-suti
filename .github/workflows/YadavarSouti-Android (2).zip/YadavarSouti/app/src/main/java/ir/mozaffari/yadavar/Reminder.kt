package ir.mozaffari.yadavar

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar

/**
 * یک یادآور.
 * voice: مسیر فایل پیام صوتی ضبط‌شده (در حافظه داخلی گوشی)
 * image: مسیر تصویر پیوست‌شده (کپی‌شده از گالری در حافظه داخلی)
 * repeat: نوع تکرار (Repeat)  —  pre: اعلان زودتر، به دقیقه (۰ = ندارد)
 */
data class Reminder(
    val id: Long,
    val text: String,
    val at: Long,
    val done: Boolean = false,
    val voice: String? = null,
    val image: String? = null,
    val repeat: Int = Repeat.NONE,
    val pre: Int = 0,
)

object Repeat {
    const val NONE = 0
    const val DAILY = 1
    const val WEEKLY = 2
    const val MONTHLY = 3
    const val YEARLY = 4

    val OPTIONS = listOf(NONE to "بدون تکرار", DAILY to "هر روز", WEEKLY to "هر هفته", MONTHLY to "هر ماه", YEARLY to "هر سال")
    fun label(kind: Int) = OPTIONS.firstOrNull { it.first == kind }?.second ?: ""

    /** زمان نوبت بعدی؛ برای ماهانه و سالانه بر اساس تقویم شمسی */
    fun next(at: Long, kind: Int): Long? {
        val c = Calendar.getInstance().apply { timeInMillis = at }
        return when (kind) {
            DAILY -> c.apply { add(Calendar.DAY_OF_YEAR, 1) }.timeInMillis
            WEEKLY -> c.apply { add(Calendar.DAY_OF_YEAR, 7) }.timeInMillis
            MONTHLY, YEARLY -> {
                val j = Jalali.fromMillis(at)
                val n = Jalali.addMonths(j, if (kind == MONTHLY) 1 else 12)
                Jalali.toMillis(n.jy, n.jm, n.jd, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
            }
            else -> null
        }
    }
}

val PRE_OPTIONS = listOf(
    0 to "ندارد", 5 to "۵ دقیقه قبل", 15 to "۱۵ دقیقه قبل", 30 to "۳۰ دقیقه قبل",
    60 to "۱ ساعت قبل", 180 to "۳ ساعت قبل", 1440 to "۱ روز قبل",
)

/** ذخیره یادآورها روی گوشی */
object ReminderStore {
    private const val PREF = "reminders"
    private const val KEY = "items"

    @Synchronized
    fun all(ctx: Context): List<Reminder> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Reminder(
                id = o.getLong("id"),
                text = o.getString("text"),
                at = o.getLong("at"),
                done = o.optBoolean("done", false),
                voice = o.optString("voice", "").ifEmpty { null },
                image = o.optString("image", "").ifEmpty { null },
                repeat = o.optInt("repeat", Repeat.NONE),
                pre = o.optInt("pre", 0),
            )
        }.sortedBy { it.at }
    }

    @Synchronized
    private fun saveAll(ctx: Context, list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach {
            val o = JSONObject().put("id", it.id).put("text", it.text).put("at", it.at).put("done", it.done)
                .put("repeat", it.repeat).put("pre", it.pre)
            if (it.voice != null) o.put("voice", it.voice)
            if (it.image != null) o.put("image", it.image)
            arr.put(o)
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun pending(ctx: Context) = all(ctx).filter { !it.done }
    fun get(ctx: Context, id: Long) = all(ctx).firstOrNull { it.id == id }
    fun add(ctx: Context, r: Reminder) = saveAll(ctx, all(ctx) + r)
    fun update(ctx: Context, r: Reminder) = saveAll(ctx, all(ctx).map { if (it.id == r.id) r else it })

    fun delete(ctx: Context, id: Long) {
        get(ctx, id)?.let { deleteFiles(it) }
        saveAll(ctx, all(ctx).filter { it.id != id })
    }

    fun markDone(ctx: Context, id: Long) {
        val monthAgo = System.currentTimeMillis() - 30L * 86_400_000L
        val updated = all(ctx).map { if (it.id == id) it.copy(done = true) else it }
        val (keep, drop) = updated.partition { !it.done || it.at > monthAgo }
        drop.forEach { deleteFiles(it) }
        saveAll(ctx, keep)
    }

    /** پس از خاموش کردن آلارم: اگر تکرارشونده است نوبت بعدی تنظیم می‌شود، وگرنه انجام‌شده علامت می‌خورد */
    fun complete(ctx: Context, id: Long) {
        val r = get(ctx, id) ?: return
        var next = Repeat.next(r.at, r.repeat)
        if (next == null) { markDone(ctx, id); return }
        val now = System.currentTimeMillis()
        while (next != null && next <= now) next = Repeat.next(next, r.repeat)
        val u = r.copy(at = next ?: return)
        update(ctx, u)
        AlarmScheduler.schedule(ctx, u)
    }

    private fun deleteFiles(r: Reminder) {
        r.voice?.let { File(it).delete() }
        r.image?.let { File(it).delete() }
    }

    /** پاک کردن فایل‌های صوتی و تصویری که به هیچ یادآوری وصل نیستند (مثلاً ضبط‌شده ولی ثبت‌نشده) */
    fun cleanup(ctx: Context) {
        val used = all(ctx).flatMap { listOfNotNull(it.voice, it.image) }.toSet()
        val dayAgo = System.currentTimeMillis() - 86_400_000L
        listOf("voice", "images").forEach { dir ->
            File(ctx.filesDir, dir).listFiles()?.forEach { f ->
                if (f.absolutePath !in used && f.lastModified() < dayAgo) f.delete()
            }
        }
    }
}

/** معمای ریاضی ساده برای خاموش کردن آلارم */
data class Puzzle(val question: String, val answer: Int) {
    companion object {
        fun make(): Puzzle {
            val r = java.util.Random()
            fun rnd(a: Int, b: Int) = a + r.nextInt(b - a + 1)
            return when (r.nextInt(3)) {
                0 -> { val a = rnd(12, 59); val b = rnd(11, 39); Puzzle("$a + $b", a + b) }
                1 -> { val a = rnd(3, 9); val b = rnd(4, 9); Puzzle("$a × $b", a * b) }
                else -> { val a = rnd(30, 80); val b = rnd(10, 29); Puzzle("$a − $b", a - b) }
            }
        }
    }
}
