plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "ir.mozaffari.yadavar"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.mozaffari.yadavar"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }

    // کلید امضای ثابت: هر بار که GitHub نسخه جدید می‌سازد، روی نسخه قبلی نصب می‌شود (بدون حذف و از دست رفتن یادآورها)
    signingConfigs {
        create("yadavar") {
            storeFile = file("yadavar.jks")
            storePassword = "yadavar1405"
            keyAlias = "yadavar"
            keyPassword = "yadavar1405"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("yadavar")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("yadavar")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
}
